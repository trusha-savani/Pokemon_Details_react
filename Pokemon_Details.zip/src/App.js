import './App.css';
import Card from './component/Card';
import Footer from './component/Footer';
import Navbar from './component/Navbar';
import Search from './component/Search';

function App() {
  return (
    <div className="App">
     <Navbar />
     <Search />
     <Card />
     <Footer />
    </div>
  );
}

export default App;
