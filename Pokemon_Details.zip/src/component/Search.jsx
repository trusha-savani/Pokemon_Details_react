import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { FaAngleDown } from "react-icons/fa6";

const Search = () => {
  const [types, setTypes] = useState([]);
  const [selectedType, setSelectedType] = useState(null);
  const [isOpen, setIsOpen] = useState(false);

let fatchtypes =()=>{
    axios.get('https://pokeapi.co/api/v2/type')
    .then((res)=>{
      setTypes(res.data.results)
    }) 
    .catch((err)=>{
      console.log(err);
    })
  }
useEffect(() => {
    fatchtypes();
  }, []);

  const handleTypeSelect = (type) => {
    setSelectedType(type);
    setIsOpen(false);
  };

return (
    <div className="relative  text-left p-4">
      
      <div className="flex justify-center items-center container mx-auto">
       
      <button
        type="button"
        className="inline-flex w-96 items-center justify-between gap-x-1.5 rounded-md bg-gray-800 text-white px-3 py-3 text-md font-semibold text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 hover:bg-white-50"
        id="menu-button"
        aria-expanded={isOpen}
        aria-haspopup="true"
        onClick={() => setIsOpen(!isOpen)}
      >
        {selectedType ? selectedType.name : 'Select category'}
        <FaAngleDown className="ml-2" />
      </button>
    </div>

      {isOpen && (
        <div class="flex justify-center container mx-auto mr-4">
          
        <div className="absolute    flex  flex-nowrap z-10 mt-2 w-96  hover:text-white rounded-md bg-white shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none" role="menu" aria-orientation="vertical" aria-labelledby="menu-button" tabIndex="-1">
          <div className="py-1" role="none">
            {types.map((type, index) => (
              <a
                href="#"
                key={index}
                className="text-black block text-xl px-4 py-2  w-full "
                
                role="menuitem"
                tabIndex="-1"
                onClick={() => handleTypeSelect(type)}
              >
                {type.name} 
             
              </a>
            ))}
          </div>
        </div>
        </div>
      )}
    </div>
  );
};

export default Search;




