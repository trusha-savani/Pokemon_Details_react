import React from 'react'
import { TbDots } from "react-icons/tb";
function Footer() {
  return (
    <div className=" bg-gray-800">
            <div className="flex flex-col mt-4 xs-col-12">
                <div className='mt-5'>
                <ul className="flex  mr-3 text-white  items-center justify-center  ">
                <li> <a className="New-Style orange mr-3" href="http://localhost:3000/"> POKEMONES : 250 </a> </li>
                <li> <a className="New-Style orange mr-3" href="http://localhost:3000/"> LOCATIONS : 10 </a> </li>
                <li> <a className="New-Style orange" href="http://localhost:3000/"> CATEGORY : 20 </a> </li>
            </ul>
                </div>
                <div className="text-center mt-4 text-white font-semibold text-xl">
                    <a className="status New-Style orange" href="http://localhost:3000/"> SERVER STATUS  </a>
                </div>
                <div className="flex flex-col justify-center items-center">
                    <img src="https://www.cdmi.in/companies/multicode-solutions.png" className='w-40' alt="NOT FOUND" />
                    <img src="https://www.cdmi.in/companies/Nexios-Technologies-LLP.png" className='w-40' alt="NOT FOUND" />
                </div>
                <div  className="flex items-center justify-center">
                    <a className="New-Style" href="http://localhost:3000/"> <TbDots className='text-white text-8xl' /> </a> 
                </div>
                <div className="text-center text-white mt-">
                    <p> ❮ ❯  &nbsp; by Axel Pokemon &nbsp; 2024  &nbsp;</p>
                </div>
            </div>
        </div>
  )
}

export default Footer
