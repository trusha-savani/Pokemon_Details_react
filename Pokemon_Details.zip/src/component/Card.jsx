import React, { useEffect, useState } from "react";
import axios from "axios";

const typeImages = {
  bulbasaur:"https://images-wixmp-ed30a86b8c4ca887773594c2.wixmp.com/f/40058df6-738b-475d-be76-a43dcca26b02/daf4eu8-a9acb0ce-f84e-45bd-9dbb-4a7f603747a4.jpg/v1/fill/w_1024,h_732,q_75,strp/bulbasaur__pokemon_drawing__by_unlooseart_daf4eu8-fullview.jpg?token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1cm46YXBwOjdlMGQxODg5ODIyNjQzNzNhNWYwZDQxNWVhMGQyNmUwIiwiaXNzIjoidXJuOmFwcDo3ZTBkMTg4OTgyMjY0MzczYTVmMGQ0MTVlYTBkMjZlMCIsIm9iaiI6W1t7ImhlaWdodCI6Ijw9NzMyIiwicGF0aCI6IlwvZlwvNDAwNThkZjYtNzM4Yi00NzVkLWJlNzYtYTQzZGNjYTI2YjAyXC9kYWY0ZXU4LWE5YWNiMGNlLWY4NGUtNDViZC05ZGJiLTRhN2Y2MDM3NDdhNC5qcGciLCJ3aWR0aCI6Ijw9MTAyNCJ9XV0sImF1ZCI6WyJ1cm46c2VydmljZTppbWFnZS5vcGVyYXRpb25zIl19.zb9Dyv6ZVEiw0iDy6RlJ4ira0y5Esvzk7-UoixCM5WQ",
  ivysaur: "https://wallpapercave.com/wp/wp2388399.jpg",
  venusaur: "https://wallpapers.com/images/hd/venusaur-white-background-hccksei7uh84lnl9.jpg",
  charmander: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRZmOgxUKPEgWZI1XEeaOcjmRK_ZPmToEdXgg&s",
  charmeleon: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRdcXb_27azFq3NgvKv1azG77-r-5Hb9fXbHQ&s",
  charizard: "https://wallpapers.com/images/featured/charizard-81j38es78uba4o6j.jpg",
  squirtle: "https://wallpapers.com/images/featured/squirtle-h6x0uzslec9uezge.jpg",
  wartortle: "https://wallpapercave.com/wp/wp2393653.jpg",
  blastoise: "https://www.pngitem.com/pimgs/m/202-2029073_mega-blastoise-pokemon-mega-evolution-blastoise-hd-png.png",
  caterpie: "https://c4.wallpaperflare.com/wallpaper/241/139/747/background-caterpie-pokemon-simple-wallpaper-preview.jpg",
};

const Card = () => {
  const [data, setData] = useState("");
  const [results, setResults] = useState([]);
  const [filteredResults, setFilteredResults] = useState([]);
  const [selectedPokemon, setSelectedPokemon] = useState(null);
  const [modalOpen, setModalOpen] = useState(false);

  const fetchdata = () => {
    axios.get("https://pokeapi.co/api/v2/pokemon?limit=10")
      .then((res) => {
        setResults(res.data.results);
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const fetchpokemondetails = (pokemonname) => {
    axios.get(`https://pokeapi.co/api/v2/pokemon/${pokemonname}`)
      .then((res) => {
        setSelectedPokemon(res.data);
        setModalOpen(true);
      })
      .catch((err) => {
        console.error("Error fetching Pokémon details:", err);
      });
  };

  useEffect(() => {
    fetchdata();
  }, []);

  useEffect(() => {
    const filterResults = () => {
      const filtered = results.filter((result) =>
        result.name.toLowerCase().includes(data.toLowerCase())
      );
      setFilteredResults(filtered);
    };
    filterResults();
  }, [data, results]);

  const handlePokemonClick = (pokemonName) => {
    fetchpokemondetails(pokemonName);
  };

  const handleCloseModal = () => {
    setSelectedPokemon(null);
    setModalOpen(false);
  };

  return (
    <div className="p-4 bg-gray-100 min-h-screen">
      <input
        className="w-full p-4 border border-gray-300 rounded mb-4"
        placeholder="Search Pokemon..."
        value={data}
        onChange={(e) => setData(e.target.value)}
      />
      <div className="grid gap-4 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
        {filteredResults.map((result, index) => (
          <div
            key={index}
            className="bg-white border border-gray-200 rounded-lg shadow-md flex flex-col items-center text-center cursor-pointer transition-transform transform hover:scale-105"
            onClick={() => handlePokemonClick(result.name)}
          >
            <img
              src={typeImages[result.name]}
              alt={result.name}
              className="w-full h-48 object-cover mb-3 rounded-t-lg"
            />
            <div className="text-lg font-bold bg-gray-800 text-white w-full py-3 rounded-b-lg">
              {result.name.charAt(0).toUpperCase() + result.name.slice(1)}
            </div>
          </div>
        ))}
      </div>
   
      {modalOpen && selectedPokemon && (
        <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
          <div className="bg-white p-8 rounded-lg shadow-lg w-11/12 md:w-1/2 lg:w-1/3">
            <div className="mx-auto mb-4 bg-gray-200 rounded-lg p-2">
              <img
                src={typeImages[selectedPokemon.name]}
                alt={selectedPokemon.name}
                className="w-96 h-60 rounded-lg mx-auto"
              />
            </div>
            <h2 className="text-xl font-semibold mb-1 flex items-center ">
              <div className="font-bold mr-3 text-sky-950">Name:</div>
              {selectedPokemon.name.charAt(0).toUpperCase() + selectedPokemon.name.slice(1)}
            </h2>
            <h2 className="text-xl font-semibold mb-1 flex ">
              <div className="font-bold mr-3 text-sky-950">Type:</div>
              {selectedPokemon.types
                .map((typeInfo) => typeInfo.type.name.charAt(0).toUpperCase() + typeInfo.type.name.slice(1))
                .join(", ")}
            </h2>
         
            <p className="mt-3 text-neutral-400">
            <h2 className=" text-xl font-bold mb-2 text-sky-950">Stats:</h2>
              {selectedPokemon.stats.map((stat) => (
                <div className="" key={stat.stat.name}>
                  {stat.stat.name.charAt(0).toUpperCase() + stat.stat.name.slice(1)}: {stat.base_stat}
                </div>
              ))}
            </p>
            <p className="mt-3 text-neutral-400">
            <h2 className="text-xl font-bold text-sky-950">  Abilities:</h2>
            <div className="flex flex-col">

              {selectedPokemon.abilities
                .map((ability) => ability.ability.name.charAt(0).toUpperCase() + ability.ability.name.slice(1))
                .join(", ")}
            </div>
            </p>
            <p className="mt-3 text-neutral-400">
              <h2 className="font-bold text-xl text-sky-950">Moves:</h2>
              {selectedPokemon.moves.slice(0, 5).map((move) => (
                <div key={move.move.name}>
                  {move.move.name.charAt(0).toUpperCase() + move.move.name.slice(1)}
                </div>
              ))}
            </p>
            <div className="text-end mt-2">
              <button
                className="px-4 py-2 bg-gray-800 text-white rounded hover:bg-gray-700 transition"
                onClick={handleCloseModal}
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Card;
